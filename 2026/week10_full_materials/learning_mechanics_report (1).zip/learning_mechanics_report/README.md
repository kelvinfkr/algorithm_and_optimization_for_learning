# 学习力学阅读报告

本文件夹是一份针对 Simon 等《There Will Be a Scientific Theory of Deep Learning》(arXiv:2604.21691) 的阅读报告 LaTeX 源码。

## 在 Overleaf 上使用（推荐）

1. 打开 https://www.overleaf.com 并登录。
2. **New Project → Upload Project**，把本文件夹的 zip 整体拖入；或新建空项目后上传 `main.tex`。
3. 项目打开后：**Menu → Compiler → 选择 XeLaTeX**。
4. **Recompile** 即可生成 PDF。

> 编译器必须选 **XeLaTeX**（不是 pdfLaTeX），因为本文使用了 `ctexart` 文档类来支持中文。Overleaf 默认 TeX Live 已包含 `ctex` 与所需中文字体，无需额外配置。

## 本地编译

需要 TeX Live 完整版（含中文支持）：

```bash
sudo apt install texlive-full        # 或仅装 texlive-lang-chinese 与 texlive-xetex
xelatex main.tex
xelatex main.tex                     # 第二次以正确生成目录与交叉引用
```

## 文件清单

- `main.tex` — 主文档
- `README.md` — 本说明文件
